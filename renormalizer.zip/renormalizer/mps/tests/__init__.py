# -*- coding: utf-8 -*-
# Author: Jiajun Ren <jiajunren0522@gmail.com>

import os

cur_dir = os.path.dirname(os.path.abspath(__file__))
